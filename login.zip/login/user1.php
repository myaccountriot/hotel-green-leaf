<?php
class User
{
  
    // database connection and table name
    private $conn;
    private $table_name = "user_info";
 
    // object properties

    public $Email;

    public $Contact_No;

    public $Username;

    public $Password;

    public $access_level;
    
    // constructor
    public function __construct($db){
        $this->conn = $db;
    }
    // check if given email exist in the database
function UsernameExists(){
 
    // query to check if email exists
    $query = "SELECT  Username, Password, access_level
            FROM " . $this->table_name . "
            WHERE Username = ?";

//  echo $this->email;
    // prepare the query
    $stmt = $this->conn->prepare( $query );
 
    // sanitize
    $this->Username=htmlspecialchars(strip_tags($this->Username));
    //$this->Password=htmlspecialchars(strip_tags($this->Password));

 
    // bind given email value
    $stmt->bindParam(1, $this->Username);
    //$stmt->bindParam(1, $this->Password);
 
    // execute the query
    $stmt->execute();
 
    // get number of rows
    $num = $stmt->rowCount();
     echo $num;
    // if email exists, assign values to object properties for easy access and use for php sessions
    if($num>0){
 
        // get record details / values
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
        // assign values to object properties
        
        $this->Username = $row['Username'];
        //$this->Contact_No = $row['Contact_No'];
        //$this->Email = $row['Email'];
        $this->Password = $row['Password'];
        $this->access_level = $row['access_level'];
 
        // return true because email exists in the database
        return true;
    }
 
    // return false if email does not exist in the database
    return false;
}

}
