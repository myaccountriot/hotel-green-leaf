<?php
include_once 'header.php';
include_once 'database.php';
include_once 'student.php';
// instantiate database and student object
$database = new Database();
$db = $database->getConnection();

$objStud = new Student($db);

$page_title = "Add Student";

  
// contents will be here
echo "<div class='right-button-margin'>";
echo "<a href='getStud.php' class='btn btn-primary pull-right'>";
echo "<span class='glyphicon glyphicon-plus'></span> Read Students";
echo "</a>";
echo "</div>";
echo "</br>";
echo "</br>";
?>
<!-- post code will be here -->
<?php 
// if the form was submitted
if($_POST){
  
    // set student property values
    
    $objStud->User_id = $_POST['User_id'];
    $objStud->Username = $_POST['Username'];
    $objStud->Contact_No = $_POST['Contact_No'];
    $objStud->Email = $_POST['Email'];
    $objStud->Password = $_POST['Password'];
    
    
    // add  student
    if($objStud->create()){
        echo "<div class='alert alert-success alert-dismissable'>";
            echo "Student is Added Successfully";
        echo "</div>";
    }
  
    // if unable to update the student, tell the user
    else{
        echo "<div class='alert alert-danger alert-dismissable'>";
            echo "Unable to add student.";
        echo "</div>";
    }
}
?>
<!-- 'Update Student' form will be here -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] );?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
  
        <tr>
            <td>User_id</td>
            <td><input type='text' readonly name='User_id'   
            class='form-control'  /></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><input type='text' name='Email'   class='form-control' /></td>
        </tr>
        <tr>
            <td>Contact_No</td>
            <td><input type='text' name='Contact_No'   class='form-control' /></td>
        </tr>
        <tr>
            <td>Username</td>
            <td><input type='text' name='Username'   class='form-control' />
            </td>
     
        </tr>
        <tr>
            <td>Password</td>
            <td><input type='text' name='Password'   class='form-control' /></td>
        </tr>
        
        <tr>
            <td></td>
            <td>
                <button type="submit" class="btn btn-primary">Add</button>
            </td>
        </tr>
  
    </table>
</form>
<?php



echo "</div>";
include_once 'footer.php';
?>

