<html>
    <head>
        <title>Log In Page</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <style>
            body{
                background-image: url("back3.jpeg");
                background-size: 100% 100%;  
                background-repeat: no-repeat;              
                width: 100%;
                height: 100%;
            }
            #d1{
                width: 100%;
                height: 10%; 
                color: white;
            }
            .aa{
                float: right;
                margin-top: 1%;
                font-size: 15px;
                margin-right: 40px;
                color: #249824;
                border: 2px solid #249824;
                border-radius: 5px;
                padding: 5px 5px 2px 5px;
                
            }
            .aa:hover{
                background: #249824;
                color: white;
                box-shadow:3px 3px 3px 3px black;
                text-decoration: none;
            }

            #a1{
                box-shadow:5px 5px 5px 5px;
                margin: 10px 5% 3% 23.1%;
                width: 70%;
                height: 85%;
            }
            #a2{
                width: 30%;
                height: 100%;
                float: left;
                background-color: #249824;
            }
            #a3{
                width: 69.5%;
                height: 100%;
                float: right;
                background-color: white;
            }
            img{
                height: 40%;
                width: 80%;
                margin-left: 10%;
                margin-top: 40%;
                border-radius: 50px;
                box-shadow:5px 5px 5px 5px;
            }
            h1{
                text-align:center; 
                margin-top: 15%;
            }
            .l1{
                    position: absolute;
                    pointer-events: none;
                    margin: 5px 6%; 
                    transition: 0.5s;
                    font-size: 20px;
                    transform: translateY(-160%);
            }
            .c2{

                width:80%;
                height: 40px;
                border: none;
                border-bottom:2px solid;
                outline: none;
                margin: 5px 10%;
                padding: 0 35px 0 5px;
            }
            #a3 input:valid ~ label,
            #a3 input:focus ~ label
            {
                color: #249824;
                transform: translateY(-64px);
                font-size: 15px;
            }
            i{
               float: right;
               margin-right: 11%;
               transform: translateY(200%);
            }
            #b1{
                text-align: center;
                display: inline-block;
                font-size: 15px;
                margin-left: 15%;                
                margin-top: 1.5%;
                background-color: white;
                border: #249824;
                border-radius: 6px;
                box-shadow:3px 3px 3px 3px #249824;
                width: 70%;
                height: 8%;
            }
            #b1:hover{
                background: #249824;
                color: white;
                box-shadow:3px 3px 3px 3px black;
            }
            #a4{
                margin-left: 10%;
                size: 25px;
                accent-color: #249824;
            }
            #a5{
                float: right;
                margin-right: 30%;
                margin-top: 2%;
            }
        </style>
    </head>
<body>
    
<?php
    include_once 'C:\xampp\htdocs\crud\project/database.php';
    include_once 'reg_conn.php';
    // instantiate database and student object
    $database = new Database();
    $db = $database->getConnection();

    $objStud = new Student($db);

$page_title = "Add Student";
?>

<!-- post code will be here -->
<?php 
// if the form was submitted
if($_POST){
  
    // set student property values
    
    //$objStud->User_id = $_POST['User_id'];
    $objStud->Username = $_POST['Username'];
    $objStud->Contact_No = $_POST['Contact_No'];
    $objStud->Email = $_POST['Email'];
    $objStud->Password = $_POST['Password'];
    
    
    // add  student
    $objStud->create();
}
?>
<!-- 'Update Student' form will be here -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] );?>" method="post">
<div id="d1">
            <a href="http://localhost/crud/project/login/login.php" class="aa">LOGIN</a>
            <a href="" class="aa">ABOUT US</a>
            <a href="" class="aa">CONTACT US</a>
            <a href="" class="aa">HOME</a>
        </div>
        <div id="a1">
            <div>
                <div id="a2">
                    <img src="logo3.png" alt="Hotel Logo">
                    <h3 align="center" style="color:white;">India's Luxuries Hotel <br> And <br>Restaurant</h3>
                </div>
                <div id="a3">
                    <h1>Registration</h1>

                    <i class="glyphicon glyphicon-envelope"></i>
                    <input type="text" class="c2" name="Email"  required pattern="[A-Za-z0-9]+@[a-z]+.[a-z]{2,}$">
                    <label for="Email" class="l1">Email</label>

                    <i class="glyphicon glyphicon-phone"></i>
                    <input type="text" class="c2" name='Contact_No' required pattern="[0-9]{10}$">
                    <label for="Contact_No" class="l1">Contact No.</label>

                    <i class="glyphicon glyphicon-user"></i>
                    <input type="text" name='Username' class="c2" required pattern="[A-Za-z@#$%*0-9]{4,}$">
                    <label for="Username" class="l1">Username</label>

                    <i class="glyphicon glyphicon-lock"></i>
                    <input type="password" class="c2" name='Password' required pattern="[A-Za-z@#$%*0-9]{8}$"><br>
                    <label for="password" class="l1">Password</label>

                    <p id="a4"><input type="checkbox" required>I agree to the terms & condition</p>
                            
                    <button id="b1"><b>Register</b></button>
                    <h5 id="a5">Already have an account?<a href="http://localhost/crud/project/login/login.php">Log in</h5></a>
                </div>
            </div>
        </div>
        </form>
    </body>
</html>