<?php
include_once 'database.php';
include_once 'student.php';
include_once 'header.php';
// instantiate database 
$database = new Database();
$db = $database->getConnection();

//create student object
$objStud = new Student($db);
$stmt = $objStud->search();

$total_rows=$stmt->rowCount();

echo "<div class='col-md-12'>"; 

// add Student button
echo "<div class='right-button-margin'>";
    echo "<a href='add_stud.php' class='btn btn-primary pull-right'>";
        echo "<span class='glyphicon glyphicon-plus'></span> Create Student";
    echo "</a>";
echo "</div>";
echo "</br>";
echo "</br>";

if($total_rows>0){

    echo "<table class='table table-hover table-responsive table-bordered'>";
        echo "<tr>";
            echo "<th>User_id</th>";
            echo "<th>Email</th>";
            echo "<th>Contact_No</th>";
            echo "<th>Username</th>";
            echo "<th>Password</th>";
            echo "</tr>";

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            echo "<tr>";
            
            echo "<td>{$User_id}</td>";
            echo "<td>{$Email}</td>";
            echo "<td>{$Contact_No}</td>";
            echo "<td>{$Username}</td>";
            echo "<td>{$Password}</td>";
    
            echo "<td>";
    
                // Edit student
                echo "<a href='update_stud.php?User_id={$User_id}' class='btn btn-info left-margin'>";
                    echo "<span class='glyphicon glyphicon-edit'></span> Edit ";
                echo "</a> &nbsp";
    
                // delete downloads button
                echo "<a href='delete_stud.php?User_id={$User_id}' class='btn btn-danger delete-object'>";
                    echo "<span class='glyphicon glyphicon-remove'></span> Delete";
                echo "</a> &nbsp";
    
    
            echo "</td>";
    
        echo "</tr>";
        
        }
        echo "</table>";
    }

?>


<?php
include_once 'footer.php';
?>