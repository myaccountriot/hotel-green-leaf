<?php
class Student
{
    private $conn;
   
    private $table_name = "User_Info";
   

    // object properties
    public $Email;

    public $Contact_No;

    public $Username;

    public $Password;

    public function __construct($db){
        $this->conn = $db;
       // echo $this->conn;
    }
    public function search()
    {
        // select query
        $query = "SELECT * from User_Info";
                
        //echo "<br>" .$query;
        // prepare query statement
        $stmt = $this->conn->prepare( $query );
        
        // execute query
        $stmt->execute();
        // echo "<br>" .$stmt->rowCount();
        
        // return values from database
        return $stmt;
    }

    //Create student
    function create(){
                
        $query = "insert into
                    " . $this->table_name . "
                    (Email,Contact_No,Username,Password)
                values (
                    :Email,
                    :Contact_No,
                    :Username,
                    :Password    
                )";
        $stmt = $this->conn->prepare($query);
        
        // posted values
        // $this->rollno=htmlspecialchars(0);
        $this->Email=htmlspecialchars(strip_tags($this->Email));
        $this->Contact_No=htmlspecialchars(strip_tags($this->Contact_No));
        $this->Username=htmlspecialchars(strip_tags($this->Username));
        $this->Password=htmlspecialchars(strip_tags($this->Password));
        
        
        // bind parameters
        // $stmt->bindParam(":rollno", $this->rollno);
        $stmt->bindParam(":Email", $this->Email);
        $stmt->bindParam(":Contact_No", $this->Contact_No);
        $stmt->bindParam(":Username", $this->Username);
        $stmt->bindParam(":Password", $this->Password);
        
        // execute the query
        if($stmt->execute()){
            return true;
        }
      
        return false;
          
    }


    
    function readOne(){
  
        $query = "SELECT * FROM  " . $this->table_name . " WHERE User_id = ? LIMIT 0,1";
      
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->User_id);
        
        $stmt->execute();
      
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
      
        $this->name = $row['Username'];
        $this->mobile = $row['Contact_No'];
        $this->email = $row['Email'];
       
    }

    //update student
    function update(){
                
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    Username=:Username,
                    Contact_No=:Contact_No,
                    Email=:Email    
                WHERE
                    User_id=:User_id";
        // echo $query;
        $stmt = $this->conn->prepare($query);
        
        // posted values
        $this->User_id=htmlspecialchars(strip_tags($this->User_id));
        $this->Username=htmlspecialchars(strip_tags($this->Username));
        $this->Contact_No=htmlspecialchars(strip_tags($this->Contact_No));
        $this->email=htmlspecialchars(strip_tags($this->email));
        
        // bind parameters
        $stmt->bindParam(":User_id", $this->User_id);
        $stmt->bindParam(":Username", $this->Username);
        $stmt->bindParam(":Contact_No", $this->Contact_No);
        $stmt->bindParam(":Email", $this->Email);
         
      
        // execute the query
        if($stmt->execute()){
            return true;
        }
      
        return false;
          
    }   
}
?>