<?php
include_once 'header.php';
include_once 'database.php';
include_once 'student.php';

// instantiate database and student object
$database = new Database();
$db = $database->getConnection();

$objStud = new Student($db);

//read original data

// get rollno of the student to be edited
$User_id = isset($_GET['User_id']) ? $_GET['User_id'] : die('ERROR: missing User_id.');

$objStud->User_id=$User_id;

// read the details of student to be edited
$objStud->readOne();
//ask for new data to update

// contents will be here
echo "<div class='right-button-margin'>";
echo "<a href='getStud.php' class='btn btn-primary pull-right'>";
echo "<span class='glyphicon glyphicon-plus'></span> Read Students";
echo "</a>";
echo "</div>";
echo "</br>";
echo "</br>";


?>
<?php 
// if the form was submitted
if($_POST){
  
    // set student property values
    
    $objStud->User_id = $_POST['User_id'];
    $objStud->Email = $_POST['Email'];
    $objStud->Contact_No = $_POST['Contact_No'];
    $objStud->Username = $_POST['Username'];
    $objStud->Password = $_POST['Password'];
    
    
    // update the student
    if($objStud->update()){
        echo "<div class='alert alert-success alert-dismissable'>";
            echo "Student is Updated Successfully";
        echo "</div>";
    }
  
    // if unable to update the student, tell the user
    else{
        echo "<div class='alert alert-danger alert-dismissable'>";
            echo "Unable to update student.";
        echo "</div>";
    }
}
?>
<!-- 'Update Student' form will be here -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?User_id={$User_id}");?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
  
        <tr>
            <td>User_id</td>
            <td><input type='text' readonly name='User_id' value='<?php echo $objStud->User_id; ?>'  
            class='form-control'  /></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><input type='text' name='Email'  value='<?php echo $objStud->Email; ?>'
             class='form-control' /></td>
        </tr>
        <tr>
            <td>Contact_No</td>
            <td><input type='text' name='Contact_No'  value='<?php echo $objStud->Contact_No; ?>'
             class='form-control' /></td>
        </tr>
        <tr>
            <td>Username</td>
            <td><input type='text' name='Username'  value='<?php echo $objStud->Username; ?>' 
            class='form-control' />
            </td>
     
        </tr>
        <tr>
            <td>Password</td>
            <td><input type='text' name='Password'  value='<?php echo $objStud->Password;?>'
             class='form-control' /></td>
        </tr>
        
        <tr>
            <td>
                <button type="submit" class="btn btn-primary">Update</button>
            </td>
        </tr>
  
    </table>
</form>
<?php
echo "</div>";
include_once 'footer.php';
?>