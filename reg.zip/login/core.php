<?php
 
 
// start php session
session_start();
 
$home_url="";
?>