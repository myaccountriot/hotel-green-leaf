<html>
    <head>
        <title>Log In Page</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <style>
            body{
                background-image: url("back3.jpeg");
                background-size: 100% 100%;  
                background-repeat: no-repeat;              
                width: 100%;
                height: 80%;
            }
            #d1{
                width: 100%;
                height: 10%; 
                color: white;
            }
            .aa{
                float: right;
                margin-top: 3%;
                font-size: 15px;
                margin-right: 40px;
                color: #249824;
                border: 2px solid #249824;
                border-radius: 5px;
                padding: 5px 5px 2px 5px;
                
            }
            .aa:hover{
                background: #249824;
                color: white;
                box-shadow:3px 3px 3px 3px black;
                text-decoration: none;
            }

            #a1{
                box-shadow:5px 5px 5px 5px;
                margin: 5% 5% 5% 23.1%;
                width: 70%;
                height: 90%;
            }
            #a2{
                width: 30%;
                height: 100%;
                float: left;
                background-color: #249824;
            }
            #a3{
                width: 69.5%;
                height: 100%;
                float: right;
                background-color: white;
            }
            img{
                height: 40%;
                width: 80%;
                margin-left: 10%;
                margin-top: 40%;
                border-radius: 50px;
                box-shadow:5px 5px 5px 5px;
            }
            #h{
                color:white;
            }
            h1{
                text-align:center; 
                margin-top: 15%;
            }
            .l1{
                    position: absolute;
                    pointer-events: none;
                    margin: 0 6%; 
                    transition: 0.5s;
                    font-size: 20px;
                    transform: translateY(-130%);
            }
            .c2{

                width:80%;
                height: 50px;
                border: none;
                border-bottom:2px solid;
                outline: none;
                margin: 5px 10%;
                padding: 0 35px 0 5px;
            }
            i{
               float: right;
               margin-right: 11%;
               transform: translateY(200%);
            }
            #b1{
                text-align: center;
                display: inline-block;
                font-size: 15px;
                margin-left: 15%;                
                margin-top: 3%;
                background-color: white;
                border: #249824;
                border-radius: 6px;
                box-shadow:3px 3px 3px 3px #249824;
                width: 70%;
                height: 8%;
            }
            #b1:hover{
                background: #249824;
                color: white;
                box-shadow:3px 3px 3px 3px black;
            }
            #a4{
                float: right;
                margin-right: 10%;
                font-size: 15px;
            }
            #a5{
                float: right;
                margin-right: 30%;
                margin-top: 5%;
            }
            #a3 input:valid ~ label,
            #a3 input:focus ~ label
            {
                color: #249824;
                transform: translateY(-54px);
                font-size: 15px;
            }
        </style>
           
        
    </head>
    <body>


    <?php
// set page title
include_once 'core.php';
$page_title = "Login";


if ($_POST) {


    include_once 'C:\xampp\htdocs\crud\project/database.php';
    // get database connection
    $database = new Database();
    $db = $database->getConnection();

    include_once 'user1.php';
    // initialize objects
    $user = new User($db);

    // check if email and password are in the database
    $user->Username = $_POST['Username'];
    //$user->Password = $_POST['Password'];


    // check if email exists, also get user details using this emailExists() method
    $Username_Exists = $user->UsernameExists();
    // echo $email_exists;
    if ($Username_Exists) {
        $_SESSION['logged_in'] = true;
        //$_SESSION['Password'] = $user->Password;

        $_SESSION['Username'] = $user->Username;
        $_SESSION['access_level'] = $user->access_level;



        // if access level is 'Admin', redirect to admin section
        if ($user->access_level== 'Admin') {
            header("Location: {$home_url}getStud.php");
        }

        // else, redirect only to 'Customer' section
        else {
             header("Location: {$home_url}logout.php");
        }
    } else {
         header("Location: {$home_url}logout.php");
    }
}
?>


        <form method="post">
        <div id="d1">
            <a href="http://localhost/crud/project/reg/reg.php" class="aa">Register</a>
            <a href="" class="aa">ABOUT US</a>
            <a href="" class="aa">CONTACT US</a>
            <a href="" class="aa">HOME</a>
        </div>
        <div id="a1">
            <div>
                <div id="a2">
                    <img src="logo3.png" alt="Hotel Logo">
                    <h3 align="center" id="h">India's Luxuries Hotel <br> And <br>Restaurant</h3>
                </div>
                <div id="a3">
                    <h1>LOG IN</h1>
                        <i class="glyphicon glyphicon-user"></i>
                        <input type="text" class="c2" id="Username" name="Username" required pattern="[A-Za-z@#$%*0-9]{4,}$">
                        <label for="text" class="l1">USERNAME</label>   
                        
                        <i class="glyphicon glyphicon-lock"></i>
                        <input type="password" class="c2" id="Password" name="Password" required pattern="[A-Za-z@#$%*0-9]{8}$">
                        <label for="password" class="l1">PASSWORD</label>    
                        
                        <a href="forget.html" id="a4">Forget Password?</a>
                            
                        <button id="b1" name="submit" value="submit"><b>Login</b></button>
                        <h5 id="a5">Don't have an account?<a href="http://localhost/crud/project/reg/reg.php">Register</h5></a>
                </div>
            </div>
        </div>
    </form>
    </body>
</html>