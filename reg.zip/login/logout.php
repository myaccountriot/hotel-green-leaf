<?php
// core configuration
include_once 'core.php';
include_once "database.php";
 
// destroy session, it will remove ALL session settings

session_destroy();
unset($_SESSION['logged_in']);
unset($_SESSION['Username']);
unset($_SESSION['access_level']);

//redirect to login page
header("Location: {$home_url}home.php");

?>